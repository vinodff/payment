import React, { useState, useEffect, useCallback } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { IndianRupee, CheckCircle2, Loader2, AlertCircle, Copy, CheckCheck, ShieldCheck, Clock, CreditCard } from 'lucide-react';

interface PaymentDetails {
  amount: number;
  upiId: string;
  merchantName: string;
  transactionNote: string;
  transactionId: string;
}

interface CustomerDetails {
  email: string;
  firstName: string;
  country: string;
  phone: string;
}

type PaymentStatus = 'initial' | 'pending' | 'completed' | 'failed' | 'timeout';
type FormStep = 'details' | 'payment';

function App() {
  const [step, setStep] = useState<FormStep>('details');
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('initial');
  const [copied, setCopied] = useState(false);
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes timeout
  const [verificationAttempts, setVerificationAttempts] = useState(0);
  const [customerDetails, setCustomerDetails] = useState<CustomerDetails>({
    email: '',
    firstName: '',
    country: 'India',
    phone: '',
  });

  const paymentDetails: PaymentDetails = {
    amount: 199,
    upiId: '8179418133@ibl',
    merchantName: 'Your Store',
    transactionNote: 'Purchase Payment',
    transactionId: `TXN${Date.now()}`,
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setCustomerDetails(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmitDetails = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
  };

  const upiUrl = `upi://pay?pa=${paymentDetails.upiId}&pn=${encodeURIComponent(paymentDetails.merchantName)}&am=${paymentDetails.amount}&tn=${encodeURIComponent(paymentDetails.transactionNote)}&tr=${paymentDetails.transactionId}`;

  const mockVerifyPayment = useCallback(() => {
    return verificationAttempts >= 2;
  }, [verificationAttempts]);

  const verifyPayment = useCallback(() => {
    if (paymentStatus !== 'pending') return;

    const verificationTimeout = setTimeout(() => {
      const isVerified = mockVerifyPayment();
      
      if (isVerified) {
        setPaymentStatus('completed');
        const redirectTimeout = setTimeout(() => {
          window.location.href = 'https://nexwen.store';
        }, 2000);
        return () => clearTimeout(redirectTimeout);
      } else {
        setVerificationAttempts(prev => prev + 1);
      }
    }, 3000);

    return () => clearTimeout(verificationTimeout);
  }, [paymentStatus, mockVerifyPayment]);

  useEffect(() => {
    if (paymentStatus !== 'pending') return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          setPaymentStatus('timeout');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [paymentStatus]);

  useEffect(() => {
    if (paymentStatus !== 'pending') return;

    const verificationTimer = setInterval(verifyPayment, 5000);
    return () => clearInterval(verificationTimer);
  }, [paymentStatus, verifyPayment]);

  const handleAppClick = (app: string) => {
    setPaymentStatus('pending');
    const intentUrl = `intent://${app}/pay?pa=${paymentDetails.upiId}&pn=${encodeURIComponent(paymentDetails.merchantName)}&am=${paymentDetails.amount}&tn=${encodeURIComponent(paymentDetails.transactionNote)}&tr=${paymentDetails.transactionId}#Intent;scheme=upi;package=${app};end`;
    window.location.href = intentUrl;
  };

  const copyUpiId = () => {
    navigator.clipboard.writeText(paymentDetails.upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const renderPaymentStatus = () => {
    switch (paymentStatus) {
      case 'initial':
        return null;
      case 'pending':
        return (
          <div className="flex items-center justify-center space-x-2 text-sm">
            <Loader2 className="animate-spin text-blue-600" size={20} />
            <span className="text-blue-600">Verifying payment... {formatTime(timeLeft)}</span>
          </div>
        );
      case 'completed':
        return (
          <div className="flex items-center justify-center space-x-2 text-sm bg-green-50 p-4 rounded-lg">
            <CheckCircle2 className="text-green-600" size={20} />
            <span className="text-green-600">Payment successful! Redirecting to store...</span>
          </div>
        );
      case 'failed':
        return (
          <div className="flex items-center justify-center space-x-2 text-sm bg-red-50 p-4 rounded-lg">
            <AlertCircle className="text-red-600" size={20} />
            <span className="text-red-600">Payment verification failed. Please try again.</span>
          </div>
        );
      case 'timeout':
        return (
          <div className="flex items-center justify-center space-x-2 text-sm bg-yellow-50 p-4 rounded-lg">
            <AlertCircle className="text-yellow-600" size={20} />
            <span className="text-yellow-600">Payment session timed out. Please try again.</span>
          </div>
        );
    }
  };

  const renderCustomerForm = () => (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-2xl font-bold text-gray-800">Complete your order</h1>
        <p className="text-gray-600">Fill in your details to proceed with the payment</p>
      </div>

      <div className="flex items-center justify-between space-x-4 text-sm text-gray-600">
        <div className="flex items-center space-x-2">
          <ShieldCheck size={16} className="text-green-600" />
          <span>SSL secured checkout</span>
        </div>
        <div className="flex items-center space-x-2">
          <Clock size={16} className="text-blue-600" />
          <span>24/7 support available</span>
        </div>
        <div className="flex items-center space-x-2">
          <CreditCard size={16} className="text-purple-600" />
          <span>Multiple payment options</span>
        </div>
      </div>

      <form onSubmit={handleSubmitDetails} className="space-y-4">
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address *</label>
          <input
            type="email"
            id="email"
            name="email"
            required
            value={customerDetails.email}
            onChange={handleInputChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
          />
        </div>

        <div>
          <label htmlFor="firstName" className="block text-sm font-medium text-gray-700">First Name *</label>
          <input
            type="text"
            id="firstName"
            name="firstName"
            required
            value={customerDetails.firstName}
            onChange={handleInputChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
          />
        </div>

        <div>
          <label htmlFor="country" className="block text-sm font-medium text-gray-700">Country / Region</label>
          <select
            id="country"
            name="country"
            value={customerDetails.country}
            onChange={handleInputChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
          >
            <option value="India">India</option>
          </select>
        </div>

        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Phone *</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            required
            value={customerDetails.phone}
            onChange={handleInputChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
          />
        </div>

        <div className="flex items-center justify-between bg-gray-50 p-4 rounded-lg">
          <div>
            <h3 className="font-medium">Your Order</h3>
            <div className="text-sm text-gray-600">Mega coding bundle × 1</div>
          </div>
          <div className="text-lg font-bold">₹{paymentDetails.amount.toFixed(2)}</div>
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors"
        >
          Proceed to Payment
        </button>
      </form>

      <p className="text-xs text-gray-500 text-center">
        Your personal data will be used to process your order, support your experience throughout this website,
        and for other purposes described in our privacy policy.
      </p>
    </div>
  );

  const renderPaymentSection = () => (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-bold text-gray-800">Secure Payment Gateway</h1>
        <p className="text-gray-600">Complete your purchase using UPI</p>
      </div>

      <div className="flex items-center justify-between bg-emerald-50 rounded-lg p-4">
        <div className="flex items-center space-x-2">
          <IndianRupee className="text-emerald-600" size={24} />
          <span className="text-2xl font-bold text-emerald-600">₹{paymentDetails.amount.toFixed(2)}</span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={copyUpiId}
            className="flex items-center space-x-1 text-sm text-emerald-600 hover:text-emerald-700"
          >
            {copied ? <CheckCheck size={16} /> : <Copy size={16} />}
            <span>{copied ? 'Copied!' : 'Copy UPI ID'}</span>
          </button>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-center">
          <div className="p-4 bg-white rounded-lg shadow-sm border">
            <QRCodeSVG value={upiUrl} size={200} level="H" />
          </div>
        </div>
        <p className="text-center text-sm text-gray-500">
          Scan with any UPI app to pay
        </p>
      </div>

      <div className="space-y-4">
        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-200"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-white text-gray-500">or pay using</span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <button
            onClick={() => handleAppClick('net.one97.paytm')}
            className="flex flex-col items-center justify-center p-3 rounded-lg border hover:bg-gray-50 transition-colors"
          >
            <img src="https://upload.wikimedia.org/wikipedia/commons/2/24/Paytm_Logo_%282019%29.svg" alt="Paytm" className="w-8 h-8" />
            <span className="text-xs mt-1">Paytm</span>
          </button>
          <button
            onClick={() => handleAppClick('com.google.android.apps.nbu.paisa.user')}
            className="flex flex-col items-center justify-center p-3 rounded-lg border hover:bg-gray-50 transition-colors"
          >
            <img src="https://upload.wikimedia.org/wikipedia/commons/3/31/Google_Pay_Logo.svg" alt="Google Pay" className="w-8 h-8" />
            <span className="text-xs mt-1">Google Pay</span>
          </button>
          <button
            onClick={() => handleAppClick('com.phonepe.app')}
            className="flex flex-col items-center justify-center p-3 rounded-lg border hover:bg-gray-50 transition-colors"
          >
            <img src="https://upload.wikimedia.org/wikipedia/commons/7/71/PhonePe_Logo.svg" alt="PhonePe" className="w-8 h-8" />
            <span className="text-xs mt-1">PhonePe</span>
          </button>
        </div>
      </div>

      {renderPaymentStatus()}

      <div className="text-center text-xs text-gray-500">
        <p>Transaction ID: {paymentDetails.transactionId}</p>
        <p>Secured by Your Store Payment Gateway</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8">
        {step === 'details' ? renderCustomerForm() : renderPaymentSection()}
      </div>
    </div>
  );
}

export default App;